-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 15, 2023 at 03:25 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Library`
--

-- --------------------------------------------------------

--
-- Table structure for table `Books`
--

CREATE TABLE `Books` (
  `book_id` int(11) NOT NULL,
  `book_name` varchar(100) NOT NULL,
  `book_author` varchar(100) NOT NULL,
  `book_image` varchar(255) NOT NULL,
  `book_genre` varchar(100) NOT NULL,
  `num_copies` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Books`
--

INSERT INTO `Books` (`book_id`, `book_name`, `book_author`, `book_image`, `book_genre`, `num_copies`) VALUES
(1, 'Wet Magic', 'E.Nesbit', 'Wet Magic.jpeg', 'Fantasy', 5),
(2, 'The Two Towers', 'J.R.R.Tolkien', 'The Two Towers.jpeg', 'Fantasy', 5),
(3, 'The Road To OZ', 'L.Frank Baum', 'The Road To OZ.jpeg', 'Fantasy', 5),
(4, 'The Return Of The King', 'J.R.R.Tolkien', 'The Return Of The King.jpeg', 'Fantasy', 5),
(5, 'The Magic City', 'E.Nesbit', 'The Magic City.jpeg', 'Fantasy', 5),
(6, 'The Lighting Thief', 'Rick Rior Dan', 'The Lighting Thief.jpeg', 'Fantasy', 5),
(7, 'The Golden Compass', 'Philip Pullman', 'The Golden Compass.jpeg', 'Fantasy', 5),
(8, 'The Enchanted Castle', 'E.Nesbit', 'The Enchanted Castle.jpeg', 'Fantasy', 5),
(9, 'The Cruel Prince', 'Holly Black', 'The Cruel Prince.jpeg', 'Fantasy', 5),
(10, 'The Cat In The Hat', 'Dr.Seuss', 'The Cat In The Hat.jpeg', 'Fantasy', 5),
(11, 'The BFG', 'Roald Dahl', 'The BFG.jpeg', 'Fantasy', 5),
(12, 'Ozma Of OZ', 'L.Frank Baum', 'Ozma Of OZ.jpeg', 'Fantasy', 5),
(13, 'Le Petit Prince', 'Antoine De Saint-Exupery', 'Le Petit prince.jpeg', 'Fantasy', 5),
(14, 'Harry potter the Deathly Hallows', 'J.K.Rowling', 'Harry Potter 7.jpeg', 'Fantasy', 5),
(15, 'Harry potter and the order of the phoenix', 'J.K.Rowling', 'Harry Potter 5.jpeg', 'Fantasy', 5),
(16, 'Harry potter and the prisoner of azkaban', 'J.K.Rowling', 'Harry Potter 3.jpeg', 'Fantasy', 5),
(17, 'Harry potter and the chamber of secrets', 'J.K.Rowling', 'Harry Potter 2.jpeg', 'Fantasy', 5),
(18, 'Harry potter and the philosophers stone', 'J.K.Rowling', 'Harry Potter 1.jpeg', 'Fantasy', 5),
(19, 'Hansel And Gretel', 'Val Biro', 'Hansel And Gretel.jpeg', 'Fantasy', 5),
(20, 'Game Of Thrones', 'R.R.Martin', 'Game Of Thrones.jpeg', 'Fantasy', 5),
(21, 'Charlottes Web', 'E.B.White', 'Charlottes Web.jpeg', 'Fantasy', 5),
(22, 'Charlie And The Chocolate Factory', 'Roald Dahl', 'Charlie And The Chocolate Factory.jpeg', 'Fantasy', 5),
(23, 'Around The world In Eighty Days', 'Jules Verne', 'Around The World In Eighty Days.jpeg', 'Fantasy', 5),
(24, 'A Court Of Mist And Fury', 'Sarah J.Maas', 'A Court Of Mist And Fury.jpeg', 'Fantasy', 5),
(25, 'Water for Elephants', 'Sara Gruen', 'Water_for_elephants.jpg', 'Romance', 5),
(26, 'Under the greenwood tree', 'Thomas Hardy', 'Under_the_greenwood_tree.jpg', 'Romance', 5),
(27, 'The toll-gate', 'Georgette Heyer', 'The_toll-gate.jpg', 'Romance', 5),
(28, 'The time travelers wife', 'Audrey Niffenegger', 'The_Time_Travelers_Wife.jpg', 'Romance', 5),
(29, 'The Talisman Ring', 'Georgette Heyer', 'The_Talisman_Ring.jpg', 'Romance', 5),
(30, 'The Spanish Love Deception', 'Elena Armas', 'The_Spanish_Love_Deception.jpg', 'Romance', 5),
(31, 'The Return Of The Native', 'Thomas Hardy', 'The_Return_of_the_Native.jpg', 'Romance', 5),
(32, 'The Reader', 'Bernhard Schlink', 'The_Reader.jpg', 'Romance', 5),
(33, 'The mystery of the blue tree', 'Agatha Christie', 'The_mystery_of_the_Blue_Train.jpg', 'Romance', 5),
(34, 'The mistress of Husaby', 'Sigrid Undset', 'The_mistress_of_Husaby.jpg', 'Romance', 5),
(35, 'The love hypothesis', 'Ali Hazelwood', 'The_Love_Hypothesis.jpg', 'Romance', 5),
(36, 'Sad cypress', 'Agatha Christie', 'Sad_cypress.jpg', 'Romance', 5),
(37, 'Red,White & royal blue', 'Casey Mcquiston', 'Red,White_&_Royal_Blue.jpg', 'Romance', 5),
(38, 'Milk and honey', 'Rupi Kaur', 'Milk_and_Honey.jpg', 'Romance', 5),
(39, 'Kilmeny of the Orchard', 'L.M.Montgomery', 'Kilmeny_of_the_Orchard.jpg', 'Romance', 5),
(40, 'It starts with Us', 'Colleen Hoover', 'It_Starts_With_Us.jpg', 'Romance', 5),
(41, 'Frederica', 'Georgette Heyer', 'Frederica.jpg', 'Romance', 5),
(42, 'Framley Parsonage', 'Anthony Trollope', 'Framley_parsonage.jpg', 'Romance', 5),
(43, 'Fifty Shades Darker', 'E.L.James', 'Fifty_shades_darker.jpg', 'Romance', 5),
(44, 'Cumbres Borrascosas', 'Emily Bronte', 'Cumbres_borrascosas.jpg', 'Romance', 5),
(45, 'Cranford', 'Elizabeth Gaskell', 'Cranford.jpg', 'Romance', 5),
(46, 'The Wonderful World Of OZ', 'L.Frank Baum', 'The_wonderful_world_of_Oz.jpg', 'History', 5),
(47, 'The Story Of Treasure Seekers', 'E.Nesbit', 'The_story_of_the_treasure_seekers.jpg', 'History', 5),
(48, 'The Story Of Achilles', 'Madeline Miller', 'The_Song_of_Achilles.jpg', 'History', 5),
(49, 'The Railway Children', 'E.Nesbit', 'The_Railway_Children.jpg', 'History', 5),
(50, 'The Moonstone', 'Wilkie Collins', 'The_Moonstone.jpg', 'History', 5),
(51, 'The Merchant Of Venice', 'William Shakespeare', 'The _merchant_of_Venice.jpg', 'History', 5),
(52, 'The Diary Of A Young Girl', 'Anne Frank', 'The_Diary_of_a_Young_Girl.jpg', 'History', 5),
(53, 'The Decameron', 'Giovanni Boccaccio', 'The_Decameron.jpg', 'History', 5),
(54, 'The Beautiful And Damned', 'F.Scoott Fitzgerald', 'The_beautiful_and_damned.jpg', 'History', 5),
(55, 'The Adventures of Tom Sawyer', 'Mark Twain', 'The_adventures_of_Tom_Sawyer.jpg', 'History', 5),
(56, 'Steve Jobs', 'Walter Isaacson', 'Steve_Jobs.jpg', 'History', 5),
(57, 'Sapiens', 'Yuval Noah Harari', 'Sapiens.jpg', 'History', 5),
(58, 'Romeo and Juliet', 'William Shakespeare', 'Romeo_and_Juliet.jpg', 'History', 5),
(59, 'Robinson Crusoe', 'Daniel defoe', 'Robinson_Crusoe.jpg', 'History', 5),
(60, 'Little Women', 'Louisa May Alcott', 'Little_Women.jpg', 'History', 5),
(61, 'Leaves Of Grass', 'Walt Whitman', 'Leaves_of_Grass.jpg', 'History', 5),
(62, 'La Voleuse De Livres', 'Markus Zusak', 'La_voleuse_de_livres.jpg', 'History', 5),
(63, 'La Ilamada de lo salvaje', 'Jack London', 'La_llamada_de_lo_salvaje.jpg', 'History', 5),
(64, 'Five Children And It', 'E.Nesbit', 'Five_children_and_It.jpg', 'History', 5),
(65, 'Der Scharlachrote Buchstabe Roman', 'Nathaniel Hawthorne', 'Der_scharlachrote_Buchstabe.jpg', 'History', 5),
(66, 'Beloved', 'Toni Morrison', 'Beloved.jpg', 'History', 5),
(67, 'Whispers', 'Dean Koontz', 'Whispers.jpg', 'Horror', 5),
(68, 'Thinner', 'Stephen King', 'Thinner.jpg', 'Horror', 5),
(69, 'The White Mountains', 'John Christopher', 'The_White_Mountains.jpg', 'Horror', 5),
(70, 'The Vampire Lestat', 'Anne Rice', 'The_Vampire_Lestat.jpg', 'Horror', 5),
(71, 'The Tell-Tale Heart', 'Edgar Allan Poe', 'The_Tell-Tale_Heart.jpg', 'Horror', 5),
(72, 'The Silver Eyes', 'Scott Cawthon', 'The_Silver_Eyes.jpg', 'Horror', 5),
(73, 'The New Girl', 'R.L.Stine', 'The_New_Girl.jpg', 'Horror', 5),
(74, 'Dracula', 'Bram Stoker', 'The_New_Annotated_Dracula.jpg', 'Horror', 5),
(75, 'Goosebumps', 'R.L.Stine', 'The_Haunted_Mask.jpg', 'Horror', 5),
(76, 'Night Shift', 'Stephen King', 'Night_Shift.jpg', 'Horror', 5),
(77, 'Koralina', 'Neil Gaiman', 'Koralina.jpg', 'Horror', 5),
(78, 'It', 'Stephen King', 'It.jpg', 'Horror', 13),
(79, 'Garden Of Shadows', 'V.C.Andrews', 'Garden_Of_Shadows.jpg', 'Horror', 5),
(80, 'From A Buick8', 'Stephen King', 'From_a_Buick8.jpg', 'Horror', 5),
(81, 'Four Past Midnight', 'Stephen King', 'Four_Past_Midnight.jpg', 'Horror', 5),
(82, 'Congo', 'Michael Crichton', 'Congo.jpg', 'Horror', 5),
(83, 'Christine', 'Stephen King', 'Christine.jpg', 'Horror', 5),
(84, 'Carrie', 'Stephen King', 'Carrie.jpg', 'Horror', 5),
(85, 'Breaking Dawn', 'Stphenie Meyer', 'Breaking_Dawn.jpg', 'Horror', 5),
(86, 'Warriors Fire And Ice', 'Erin Hunter', 'Warriors fire and ice.jpeg', 'Adventure', 5),
(87, 'Throne of Glass', 'Sarah J.Maas', 'Throne of Glass.jpeg', 'Adventure', 5),
(88, 'The Throne of Fire', 'Rick Rior Dan', 'The Throne Of Fire.jpeg', 'Adventure', 5),
(89, 'The Serpants Shadow', 'Rick Rior Dan', 'The Serpents Shadow.jpeg', 'Adventure', 4),
(90, 'The Pagan Lord', 'Bernard Corenwell', 'The Pagan Lord.jpeg', 'Adventure', 5),
(91, 'The Midnight Star', 'Marie Lu', 'The Midnight Star.jpeg', 'Adventure', 5),
(92, 'The Mark Of Athena', 'Rick Rior Dan', 'The Mark Of Athena.jpeg', 'Adventure', 5),
(93, 'The Lost World', 'Michael Crichton', 'The Lost World.jpeg', 'Adventure', 4),
(94, 'The Lost Hero', 'Rick Rior Dan', 'The Lost Hero.jpeg', 'Adventure', 5),
(95, 'The Lion,The Witch and The Wardrobe', 'C.S.Lewis', 'The Lion,The Witch and The Wadrobe.jpeg', 'Adventure', 5),
(96, 'The Flame Bearer', 'Bernard Corenwell', 'The Flame Bearer.jpeg', 'Adventure', 5),
(97, 'The Fix', 'David Baldacci', 'The Fix.jpeg', 'Adventure', 5),
(98, 'Six Of Crows', 'Leigh Bardugo', 'Six of Crows.jpeg', 'Adventure', 5),
(99, 'Runaway Ralph', 'Beverly Cleary', 'Runaway Ralph.jpeg', 'Adventure', 5),
(100, 'Red Pyramid', 'Rick Rior Dan', 'Red Pyramid.jpeg', 'Adventure', 5),
(101, 'Poppy ', 'Avi', 'Poopy by Avi.jpeg', 'Adventure', 5),
(102, 'Percy  Jackson', 'Rick Rior Dan', 'Percy Jackson.jpeg', 'Adventure', 5),
(103, 'Narnia', 'C.S.Lewis', 'Narnia.jpeg', 'Adventure', 5),
(104, 'Mocking Jay', 'Suzanne Collins', 'Mocking Jay.jpeg', 'Adventure', 5),
(105, 'Life Of Pi', 'Yann Martel', 'Life Of P.jpeg', 'Adventure', 5),
(106, 'Fantastic Beasts', 'J.K.Rowling', 'Fantastic Beasts.jpeg', 'Adventure', 5),
(107, 'Catching Fire', 'Suzanne Collins', 'Catching fire.jpeg', 'Adventure', 5),
(108, 'The Legend Of Luke', 'Brain Jacques', 'Brain Jacques.jpeg', 'Adventure', 5),
(109, 'Amulet', 'Kazu Kibuishi', 'Amulet.jpeg', 'Adventure', 5),
(110, 'Ultimate Spider-Man', 'Silver Sable', 'Ultimate_Spider-Man.jpg', 'Comics', 15),
(112, 'Titin In America', 'Herge', 'Tintin_in_America.jpg', 'Comics', 5),
(113, 'The war Of The Worlds', 'H.G.Wells', 'The_war_of_the_worlds.jpg', 'Comics', 5),
(114, 'The Secret Of The Unicorn', 'Herge', 'The_secret_of_the_unicorn.jpg', 'Comics', 5),
(115, 'The Murder On The Links', 'Agatha Christie', 'The_murder_on_the_links.jpg', 'Comics', 5),
(116, 'The Jungle', 'Upton Sinclair', 'The_jungle.jpg', 'Comics', 5),
(117, 'The Graveyard Book', 'Neil Gaiman', 'The_graveyard_book.jpg', 'Comics', 5),
(118, 'The Giver ', 'Lois Lowry', 'The_Giver.jpg', 'Comics', 5),
(119, 'The Forever War', 'Joe Haldeman', 'The_Forever_War.jpg', 'Comics', 5),
(120, 'The Blue Lotus', 'Herge', 'The_blue_lotus.jpg', 'Comics', 5),
(121, 'The Annotated Hunting Of The Snark', 'Lewis Carroll', 'The_Annotated_Hunting_of_the_snark.jpg', 'Comics', 5),
(122, 'RedWall', 'Brain Jacques', 'Redwall.jpg', 'Comics', 5),
(123, 'Prisoners of The Sun', 'Herge', 'Prisoners_of_the_sun.jpg', 'Comics', 5),
(124, 'Powers', 'Brian Michael', 'Powers.jpg', 'Comics', 5),
(125, 'Of Mice And Men', 'John Steinbeck', 'Of_mice_and_men.jpg', 'Comics', 5),
(126, 'No Longer Human', 'Osamu Dazai', 'No_Longer_Human.jpg', 'Comics', 5),
(127, 'Naruto', 'Masashi Kishimoto', 'Naruto.jpg', 'Comics', 5),
(128, 'Homage To Catalonia', 'George Orwell', 'Homage_to_Catalonia.jpg', 'Comics', 5),
(129, 'Heart Of Darkness', 'Joseph Conrad', 'Heart_of_darkness.jpg', 'Comics', 5),
(130, 'Capitaines Courageux', 'Rudyard Kipling', 'Capitaines_courageux.jpg', 'Comics', 5),
(131, 'Black Beauty', 'Anna Sewell', 'Black_beauty.jpg', 'Comics', 5),
(132, 'Why Not Me', 'Mindy Kaling', 'Why not me.jpeg', 'Humour', 5),
(133, 'Wilt', 'Tom Sharpie ', 'Tom Sharpie wilt.jpeg', 'Humour', 5),
(134, 'Tiny Ladies In Shiny Pants', 'Jill Soloway', 'Tiny Ladies in Shiny Pants.jpeg', 'Humour', 5),
(135, 'The Salmon Of Doubt', 'Douglas Adams', 'The Salmon Of Doubt.jpeg', 'Humour', 5),
(136, 'The Psychopath Test', 'Jon Ronson', 'The Psychopath Test.jpeg', 'Humour', 5),
(137, 'The Optimist', 'Laurence Shorter', 'The Optimist.jpeg', 'Humour', 5),
(138, 'The Jungle Book', 'Rudyard Kipling', 'The Jungle Book.jpeg', 'Humour', 5),
(139, 'The Shepherds Crown', 'Terry Pratchett', 'Terry Pratchett.jpeg', 'Humour', 5),
(140, 'Psmith In the City', 'P.G.Wodehouse', 'Psmith In The City.jpeg', 'Humour', 5),
(141, 'New Kid', 'Jerry Craft', 'New Kid.jpeg', 'Humour', 5),
(142, 'My Uncle Oswald', 'Roald Dahl', 'My Uncle Oswald.jpeg', 'Humour', 5),
(143, 'Murder On The Orient Express', 'Agatha Christie', 'Murder On The Orient Express.jpeg', 'Humour', 5),
(144, 'Aches & Pains', 'Maeve Binchy', 'Maeve Binchy.jpeg', 'Humour', 5),
(145, 'Laughing All The Way To The Mosque', 'Zarqa Nawaz', 'Laughing all the way to the mosque.jpeg', 'Humour', 5),
(146, 'How To Ruin Your Life', 'Ben Stein', 'How to ruin your life.jpeg', 'Humour', 5),
(147, 'Corazone de Vinagre', 'Anne Tyler', 'Corazone de vinagre.jpeg', 'Humour', 5),
(148, 'Castle In The Air', 'Diana Wynne Jones', 'Castle In The Air.jpeg', 'Humour', 5),
(149, 'Big Nate The Crowd Goes Wild', 'Lincoln peirce', 'Big Nate The Crowd Goes Wild.jpeg', 'Humour', 5),
(150, 'Bad Girls', 'Mike Strobel', 'Bad Girls.jpeg', 'Humour', 5),
(151, 'Bad Dog', 'M.Boldt', 'Bad Dog.jpeg', 'Humour', 5),
(152, 'Angels Rush In', 'Jilly Cooper', 'Angels Rush In.jpeg', 'Humour', 5),
(153, 'Rabbit Hill', 'Robert Lawson', '6743179-M.jpg', 'Humour', 5),
(154, 'Viability Theory', 'Jean ', 'Viability Theory.jpeg', 'Maths', 5),
(155, 'Theory Of Cryptography', 'Douglas R. Stinson', 'Theory Of Cryptography.jpeg', 'Maths', 5),
(156, 'The Nature Of Computation', 'Stephan Mertens', 'The Nature Of Computation.jpeg', 'Maths', 5),
(157, 'The Mathematics Of Medical Imaging', 'Timothy G. Feeman', 'The Mathematics of Medical Imaging.jpeg', 'Maths', 5),
(158, 'Space-Filling Curves', 'Giuseppe Peano', 'Space-Filling Curves.jpeg', 'Maths', 5),
(159, 'Modelling and simulation Of Diffusive Processes', 'S.K. Basu', 'Modelling and Simulation of Diffusive Processes.jpeg', 'Maths', 5),
(160, 'Mathematics In Computing', 'Gerard O Regan', 'Mathematics in Computing.jpeg', 'Maths', 5),
(161, 'Mathematical Foundations Of Computer Science ', ' G. Shankar Rao', 'Mathematical Foundations oF computer SCience.jpeg', 'Maths', 5),
(162, 'Maple And Mathematica', 'Carlos Lizárraga-Celaya', 'Maple and Mathematica.jpeg', 'Maths', 5),
(163, 'Linear programming', 'Lalji Prasad ', 'Linear Programming.jpeg', 'Maths', 5),
(164, 'Intelligent Computer mathematics', 'Stephan M.Watt', 'Intelligent Computer Mathematics.jpeg', 'Maths', 5),
(165, 'Information Security', 'Xuejia Lai', 'Information Security.jpeg', 'Maths', 5),
(166, 'Information processing In Cells And Tissues', 'Michal A.Lones', 'Information Processing in cells and Tissues.jpeg', 'Maths', 5),
(167, 'Guide To Scientific computing In C++', 'Joe Pitt-Fransis', 'Guide to scientific computing in C++.jpeg', 'Maths', 5),
(168, 'Graph drawing', 'Marc van Kreveld', 'Graph Drawing.jpeg', 'Maths', 5),
(169, 'Geometry Of Cuts And Metrics', ' Michel Deza', 'Geometry of cuts and metrics.jpeg', 'Maths', 5),
(170, 'Complex intelligent Systems And Their Applications', 'F Xhafa', 'Complex Intelligent systems and their applications.jpeg', 'Maths', 5),
(171, 'Code Breaking in The Pacific', 'Peter Donovan', 'Code Breaking in the Pacific.jpeg', 'Maths', 5),
(172, 'Automatic Generation of Combinatorial Test Data', 'Chang Chien', 'Automatic Generation of Combinatorial Test Data.jpeg', 'Maths', 5),
(173, 'Automated Reasoning and Mathematics', 'Mark E.Stickel', 'Automated Reasoning and Mathematics.jpeg', 'Maths', 5),
(174, 'Applications of Evolutionary Computation', 'Erik Cuevas', 'Applications of Evolutionary Computation.jpeg', 'Maths', 5),
(175, 'The Woods', 'Harlan Coben', 'The Woods.jpeg', 'Mystery', 5),
(176, 'The Tiger In The Well', 'Philip Pullman', 'The Tiger In The Well.jpeg', 'Mystery', 5),
(177, 'The Shadow In The North', 'Philip Pullman', 'The Shadow In the Night.jpeg', 'Mystery', 5),
(178, 'The Moonspinners', 'Mary Stewart', 'The Moonspinners.jpeg', 'Mystery', 5),
(179, 'The Invisible Man', 'H.G.Wells', 'The Invisible Man.jpeg', 'Mystery', 5),
(180, 'The House On The Cliff', 'Franklin W.Dixon', 'The House On the cliff.jpeg', 'Mystery', 5),
(181, 'The Green Mile', 'Stephen King', 'The Green Mile.jpeg', 'Mystery', 5),
(182, 'The Famous Five', 'Enid Blyton', 'The Famous Five.jpeg', 'Mystery', 5),
(183, 'The Adventures Of Sherlock Holmes', 'A.Conan Doyle', 'The Adventures Of Sherlock Holmes.jpeg', 'Mystery', 5),
(184, 'The ABC Muders', 'Agatha Christie', 'The ABC Murders.jpeg', 'Mystery', 5),
(185, 'Red Dragon', 'Thomas Harris', 'Red Dragon.jpeg', 'Mystery', 5),
(186, 'Paper Towns', 'John Green', 'Paper Towns.jpeg', 'Mystery', 5),
(187, 'One Of Us Is Lying', 'Karen M.McManus', 'One of Us is Lying.jpeg', 'Mystery', 5),
(188, 'Nemesis', 'Agatha Christie', 'Nemesis.jpeg', 'Mystery', 5),
(189, 'Nate The Great', 'Craig Sharmat', 'Nate The Great.jpeg', 'Mystery', 5),
(190, 'Mystery Ranch', 'Warner', 'Mystery Ranch.jpeg', 'Mystery', 5),
(191, 'My Fathers Dragon', 'Gannett', 'My Fathers Dragon.jpeg', 'Mystery', 5),
(192, 'Murder In Three Acts', 'Agatha Christie', 'Murder In Three Acts.jpeg', 'Mystery', 5),
(193, 'Mikes Mystery', 'Warner', 'Mikes Mystery.jpeg', 'Mystery', 5),
(194, 'Endless Night', 'Agatha Christie', 'Endless Night.jpeg', 'Mystery', 5),
(195, 'Cover Her Face', 'P.D.James', 'Cover her Face.jpeg', 'Mystery', 5),
(196, 'Bunnicula', 'James Howe', 'Bunnicula.jpeg', 'Mystery', 5),
(197, 'A  Guide To Murder', 'Holly Jackson', 'A Good Girls Guide to Murder.jpeg', 'Mystery', 5),
(198, 'After The Funeral', 'Agatha Christie', 'After The Funeral.jpeg', 'Mystery', 5),
(199, 'A Case Of Need', 'Jeffery Hudson', 'A Case Of need.jpeg', 'Mystery', 10),
(200, 'You Are A Badass', 'Jen Sincero', 'You_Are_a_Badass.jpg', 'Self-Help', 5),
(201, 'What every BODY is saying', 'Joe Navarro', 'What_every_BODY_is_saying.jpg', 'Self-Help', 5),
(202, 'Think Like A Monk', 'Jay Shetty', 'Think_Like_a_Monk.jpg', 'Self-Help', 5),
(203, 'The Teenage Body Book', 'Kathy', 'The_teenage_body_book.jpg', 'Self-Help', 5),
(204, 'Depression', 'Williams', 'The_psychological_treatment_of_depression.jpg', 'Self-Help', 5),
(205, 'Positive Thinking', 'Vincent', 'The_power_of_positive_thinking.jpg', 'Self-Help', 5),
(206, 'Laws of power', 'Robert Green', 'The_48_Laws_of_Power.jpg', 'Self-Help', 5),
(207, 'Radical Records', 'Bob cant', 'Radical_records.jpg', 'Self-Help', 5),
(208, 'Managing Stress', 'Chlaresworth', 'Managing_stress.jpg', 'Self-Help', 5),
(209, 'Life Coaching', 'curly Marion', 'Life_Coaching.jpg', 'Self-Help', 5),
(210, 'It Will Never Happen To Me', 'Claudia Black', 'It_Will_Never_Happen_to_Me.jpg', 'Self-Help', 5),
(211, 'Illicit Drugs', 'Adrian Barton', 'Illicit_drugs.jpg', 'Self-Help', 5),
(212, 'How To Retire Happy', 'Stan Hinden', 'How_to_retire_happy.jpg', 'Self-Help', 5),
(213, 'Boundaries', 'Henry', 'Boundaries.jpg', 'Self-Help', 5),
(214, 'Bodies That Matter', 'Butler', 'Bodies_that_matter.jpg', 'Self-Help', 5),
(215, 'Blink', 'Gladwell', 'Blink.jpg', 'Self-Help', 5),
(216, '12 Rules For Life', 'Peterson', '12_Rules_for_Life.jpg', 'Self-Help', 5),
(217, 'Wolf Tower', 'Tanith Lee', 'Wolf Tower.jpeg', 'Sci-Fi', 5),
(218, 'WaterWorld', 'Rothery', 'WaterWorld.jpeg', 'Sci-Fi', 5),
(219, 'Time Bandits', 'Michael palin', 'Time Bandits.jpeg', 'Sci-Fi', 5),
(220, 'The Snow', 'Adan Roberts', 'The Snow.jpeg', 'Sci-Fi', 5),
(221, 'The Knife Of never Letting Go', 'Patrick Ness', 'The Knife Of Never Letting Go.jpeg', 'Sci-Fi', 5),
(222, 'The Circle', 'Dave Eggres', 'The Circle.jpeg', 'Sci-Fi', 5),
(223, 'Tertiary', 'John F.Coppinger', 'Tertiary.jpeg', 'Sci-Fi', 5),
(224, 'Star Wars', 'Timothy Zahn', 'Star Wars Outbound Fight.jpeg', 'Sci-Fi', 5),
(225, 'Pursuit of Truth', 'Sarah', 'Pursuit Of Truth.jpeg', 'Sci-Fi', 5),
(226, 'Predator', 'Paul Monette', 'Predator.jpeg', 'Sci-Fi', 5),
(227, 'Planet Of Apes', 'Pierre Boulle', 'Planet Of The Apes.jpeg', 'Sci-Fi', 5),
(228, 'Lost In OZ', 'Patrick', 'Lost In OZ.jpeg', 'Sci-Fi', 5),
(229, 'Lights Outs', 'James', 'Lights Out.jpeg', 'Sci-Fi', 5),
(230, 'Iron Widow', 'Xiran Jay Zhao', 'Iron Widow.jpeg', 'Sci-Fi', 5),
(231, 'Dreamsnake', 'Vonda', 'Dreamsnake.jpeg', 'Sci-Fi', 5),
(232, 'Divergent', 'Veronica Roth', 'Divergent.jpeg', 'Sci-Fi', 5),
(233, 'Declination', 'David', 'Declination.jpeg', 'Sci-Fi', 5),
(234, 'A Wrinkle In Time', 'Madleine', 'A Wrinkle In Time.jpeg', 'Sci-Fi', 5),
(235, 'Allegiant', 'Veronica Roth', 'Allegiant.jpeg', 'Sci-Fi', 5),
(236, 'Algorithms in C', 'Robert Sedgewick', 'Algorithms in C.jpeg', 'Programming', 5),
(237, 'C In A Nutshell', 'Peter Prinz', 'C in A Nutshell.jpeg', 'Programming', 5),
(238, 'ABC Of Relativity', 'Bertrand Russell', 'ABC_of_relativity.jpg', 'Science', 18),
(239, 'Unser Kosmos', 'Carl Sagan', 'Unser_Kosmos.jpg', 'Science', 16);

-- --------------------------------------------------------

--
-- Table structure for table `Transactions`
--

CREATE TABLE `Transactions` (
  `trans_id` int(11) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `book_name` varchar(100) NOT NULL,
  `book_author` varchar(100) NOT NULL,
  `borrow_date` date NOT NULL,
  `return_by_date` date NOT NULL,
  `returned_date` date DEFAULT NULL,
  `transaction_status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Transactions`
--

INSERT INTO `Transactions` (`trans_id`, `user_email`, `book_name`, `book_author`, `borrow_date`, `return_by_date`, `returned_date`, `transaction_status`) VALUES
(1, 'cs22btech11042@iith.ac.in', 'It', 'Stephen King', '2023-07-15', '2023-08-24', '2023-07-01', 'returned'),
(3, 'cs22btech11050@iith.ac.in', 'It', 'Stephen King', '2023-07-15', '2023-08-24', '2023-07-15', 'returned'),
(4, 'cs22btech11059@iith.ac.in', 'It', 'Stephen King', '2023-07-15', '2023-08-24', '2023-07-01', 'returned'),
(5, 'cs22btech11050@iith.ac.in', 'Rabbit Hill', 'Robert Lawson', '2023-07-15', '2023-08-24', '2023-07-01', 'returned'),
(6, 'cs22btech11059@iith.ac.in', 'It', 'Stephen King', '2023-07-15', '2023-08-24', '2023-07-01', 'returned'),
(7, 'cs22btech11059@iith.ac.in', 'It', 'Stephen King', '2023-07-15', '2023-08-24', '2023-07-01', 'returned'),
(8, 'cs22btech11059@iith.ac.in', 'It', 'Stephen King', '2023-07-15', '2023-08-24', NULL, 'issued'),
(9, 'cs22btech11050@iith.ac.in', 'Beloved', 'Toni Morrison', '2023-07-15', '2023-08-24', '2023-07-03', 'returned'),
(10, 'cs22btech11050@iith.ac.in', 'Throne of Glass', 'Sarah J.Maas', '2023-07-15', '2023-08-24', '2023-07-03', 'returned'),
(11, 'cs22btech11050@iith.ac.in', 'The Serpants Shadow', 'Rick Rior Dan', '2023-07-01', '2023-08-10', NULL, 'issued'),
(12, 'cs22btech11050@iith.ac.in', 'The Lost World', 'Michael Crichton', '2023-07-01', '2023-08-10', NULL, 'issued'),
(13, 'cs22btech11050@iith.ac.in', 'Runaway Ralph', 'Beverly Cleary', '2023-07-15', '2023-08-24', '2023-07-03', 'returned'),
(14, 'cs22btech11056@iith.ac.in', 'It', 'Stephen King', '2023-07-15', '2023-08-24', '2023-07-02', 'returned'),
(15, 'cs22btech11050@iith.ac.in', 'It', 'Stephen King', '2023-07-15', '2023-08-24', '2023-07-15', 'returned'),
(16, 'cs22btech11065@iith.ac.in', 'It', 'Stephen King', '2023-07-15', '2023-08-24', NULL, 'issued'),
(17, 'cs22btech11050@iith.ac.in', 'It', 'Stephen King', '2023-07-15', '2023-08-24', NULL, 'issued');

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

CREATE TABLE `Users` (
  `user_rollno` varchar(100) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `role` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`user_rollno`, `user_name`, `user_password`, `user_email`, `role`) VALUES
('cs22btech11024', 'Gsk', '98765432', 'cs22btech11024@iith.ac.in', 'admin'),
('CS22BTECH110239', 'none', '123456789', 'cs22btech11039@iith.ac.in', 'user'),
('cs22btech11042', 'Nalavolu Chetana', '12345678', 'cs22btech11042@iith.ac.in', 'admin'),
('CS22BTECH11046', 'Yasaswini', '12346789', 'cs22btech11046@iith.ac.in', 'user'),
('cs22btech11050', 'Rishitha Surineni', 'rish1234', 'cs22btech11050@iith.ac.in', 'user'),
('cs22btech11056', 'Somalaraju Bhavya Shloka', 'shlojashloja', 'cs22btech11056@iith.ac.in', 'user'),
('cs22btech11059', 'Tumarada Padmaja', 'paddy5959', 'cs22btech11059@iith.ac.in', 'user'),
('cs22btech11065', 'Rishitha', '12345678', 'cs22btech11065@iith.ac.in', 'user'),
('cs22btech11066', 'Karthik Surineni', 'jabez_jb_insta', 'cs22btech11066@iith.ac.in', 'user'),
('CS22BTECH11066', 'Shloka', 'chukkachukka', 'cs22btech11067@iith.ac.in', 'user'),
('CS22BTECH11089', 'CHetana', '12345678', 'cs22btech11080@iith.ac.in', 'user'),
('EC20BTECH11024', 'karthik', '12345678', 'ec20btech11024@iith.ac.in', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Books`
--
ALTER TABLE `Books`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `Transactions`
--
ALTER TABLE `Transactions`
  ADD PRIMARY KEY (`trans_id`);

--
-- Indexes for table `Users`
--
ALTER TABLE `Users`
  ADD PRIMARY KEY (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Books`
--
ALTER TABLE `Books`
  MODIFY `book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=240;

--
-- AUTO_INCREMENT for table `Transactions`
--
ALTER TABLE `Transactions`
  MODIFY `trans_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
